function openPDF() {
    window.open('c.pdf', '_blank');
}
